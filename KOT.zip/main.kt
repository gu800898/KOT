  // File: main.kt
  import kotlin.concurrent.timer
  import kotlin.system.exitProcess

  // Class to store countdown information
  data class Countdown(
      var name: String,
      var interval: Int,  // in minutes
      var stopWord: String,
      var isRunning: Boolean = false
  )

  class CountdownApp {
      // Store 12 countdowns
      private val countdowns = Array(12) { index ->
          Countdown(
              name = "Countdown ${index + 1}",
              interval = 60,  // default 60 minutes
              stopWord = "stop",
              isRunning = false
          )
      }

      // Show main menu
      fun showMainMenu() {
          while (true) {
              println("\n=== Countdown Timer App ===")
              println("Choose a countdown (1-12) or 0 to exit:")

              // Show all countdowns
              for (i in countdowns.indices) {
                  val countdown = countdowns[i]
                  println("${i + 1}. ${countdown.name} ${if (countdown.isRunning) "(Running)" else ""}")
              }

              try {
                  val choice = readLine()?.toIntOrNull() ?: continue

                  when (choice) {
                      0 -> exitProcess(0)
                      in 1..12 -> showCountdownMenu(choice - 1)
                      else -> println("Please choose a number between 0 and 12")
                  }
              } catch (e: Exception) {
                  println("Please enter a valid number")
              }
          }
      }

      // Show menu for specific countdown
      private fun showCountdownMenu(index: Int) {
          val countdown = countdowns[index]

          while (true) {
              println("\n=== ${countdown.name} Settings ===")
              println("1. Change name (current: ${countdown.name})")
              println("2. Set interval (current: ${countdown.interval} minutes)")
              println("3. Set stop word (current: ${countdown.stopWord})")
              println("4. Start countdown")
              println("5. Back to main menu")

              when (readLine()) {
                  "1" -> {
                      println("Enter new name:")
                      val newName = readLine() ?: continue
                      countdown.name = newName
                      println("Name changed to: $newName")
                  }
                  "2" -> {
                      println("Enter interval in minutes (1-60):")
                      val newInterval = readLine()?.toIntOrNull() ?: continue
                      if (newInterval in 1..60) {
                          countdown.interval = newInterval
                          println("Interval set to: $newInterval minutes")
                      } else {
                          println("Please enter a number between 1 and 60")
                      }
                  }
                  "3" -> {
                      println("Enter stop word:")
                      val newStopWord = readLine() ?: continue
                      countdown.stopWord = newStopWord
                      println("Stop word set to: $newStopWord")
                  }
                  "4" -> {
                      startCountdown(countdown)
                  }
                  "5" -> return
                  else -> println("Please choose a valid option")
              }
          }
      }

      // Start the countdown
      private fun startCountdown(countdown: Countdown) {
          countdown.isRunning = true
          var timeLeft = countdown.interval * 60  // convert to seconds

          println("\nStarting ${countdown.name}")
          println("To stop, type: ${countdown.stopWord}")

          // Create timer that ticks every second
          timer(period = 1000) {
              timeLeft--

              // Show time left every 60 seconds
              if (timeLeft % 60 == 0) {
                  println("${timeLeft/60} minutes remaining")
              }

              // Time's up!
              if (timeLeft <= 0) {
                  this.cancel()
                  countdown.isRunning = false
                  ringAlarm(countdown)
              }
          }
      }

      // Ring the alarm and handle stop/snooze
      private fun ringAlarm(countdown: Countdown) {
          while (true) {
              println("\n🔔 RING! RING! ${countdown.name} 🔔")
              println("Type '${countdown.stopWord}' to stop or 'snooze' for 30 more seconds")

              when (val input = readLine()) {
                  countdown.stopWord -> {
                      println("Alarm stopped!")
                      return
                  }
                  "snooze" -> {
                      println("Snoozing for 30 seconds...")
                      Thread.sleep(30000)  // wait 30 seconds
                      println("\n🔔 RING! RING! ${countdown.name} 🔔")
                  }
                  else -> println("Wrong word! Type '${countdown.stopWord}' to stop or 'snooze'")
              }
          }
      }
  }

  fun main() {
      val app = CountdownApp()
      app.showMainMenu()
  }